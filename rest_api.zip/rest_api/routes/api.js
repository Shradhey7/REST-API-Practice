const express = require('express');
const router = express.Router();
const Ninja = require('../models/ninja');

//Get a List of Ninjas from Database
router.get('/ninjas',function(req, res){
 
 Ninja.geoNear(
        {type: 'Point', coordinates: [parseFloat(req.query.lng), parseFloat(req.query.lat)]},
        {maxDistance: 100000, spherical: true}
    ).then(function(ninjas){
        res.send(ninjas);
    }).catch(next);

});

//Adding a new Ninja to the Database
router.post('/ninjas',function(req, res, next){
   // var ninja = new Ninja(req.body);
   // ninja.save(); Below one line of code will do the job of these two lines of code.
   Ninja.create(req.body).then(function(ninja){ //.create is a mongoose method
   	res.send(ninja);
    }).catch(next); //If the user fails to give name it will give error and it will be caught by our catch code and then 'next' will say move to middleware.
});

//Update a Ninja in the Database
router.put('/ninjas/:id',function(req, res, next){
   Ninja.findByIdAndUpdate({_id: req.params.id}, req.body).then(function(){
        Ninja.findOne({_id: req.params.id}).then(function(ninja){
           res.send(ninja);    
        });
   });
   // res.send({type: 'PUT'}); 
});

//Delete a Ninja from the Database
router.delete('/ninjas/:id',function(req, res, next){
   // console.log(req.params.id);
   Ninja.findByIdAndRemove({_id: req.params.id}).then(function(ninja){
   	res.send(ninja);
   });
});

module.exports = router; //We have mounted all of the routes on 'router' and then exporting for use.
