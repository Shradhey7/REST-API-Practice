const mongoose = require('mongoose');
const Schema = mongoose.Schema;

//Creating a GeoLocation Schema
const GeoSchema = new Schema({
	
	type: {
		type: String,
		default: "Point"
	},

	coordinates: {
		type: [Number], 
		index: "2dsphere"
	}

});

//Creating Ninja Schema and Model
const NinjaSchema =  new Schema({
	name : {
		type: String,
		required: [true, "Name field is Required!"]
	},

	rank : {
		type: String
	},

	available : {
		type: Boolean,
		default: false
	},

	geometry: GeoSchema
	
});

//Creating our model
const Ninja = mongoose.model('ninja',NinjaSchema);

module.exports=Ninja; //In order to make changes to DB we need to give access to other files for using this model.